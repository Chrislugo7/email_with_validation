SELECT * FROM emails
